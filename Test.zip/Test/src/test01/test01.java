package test01;

import java.util.Calendar;

public class test01 {
	public static void main(String[] args) {
		int year = 1991;
		int age = 0;
		
		int nowYear = Calendar.getInstance().get(Calendar.YEAR);
		
		age = nowYear - year + 1;
		
		System.out.println("year : " + nowYear);
		System.out.println("age : " + age);
	}
}
