package test01;

import java.io.InputStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class test05 {
	public static void main(String[] args) {
		JSONObject student = new JSONObject();
		JSONArray students = new JSONArray();
		
		student.put("name", "KIM");
		student.put("phone", "010-1111-1111");
		student.put("address", "SEOUL");
		
		students.put(student);
			
		
		student = new JSONObject();
		
		student.put("name", "LEE");
		student.put("phone", "010-2222-2222");
		student.put("address", "BUSAN");
		
		students.put(student);
		
		JSONObject studentsList = new JSONObject();
		studentsList.put("students", students);
		
		InputStream is = test05.class.getResourceAsStream("info.json");
		JSONTokener tokener = new JSONTokener(is);
		
		JSONObject object = new JSONObject(tokener);
		JSONArray studentArray = object.getJSONArray("students");
		
		for(int i = 0; i< studentArray.length(); i++) {
			JSONObject s = studentArray.getJSONObject(i);
			System.out.print(s.getString("name") + " / ");
			System.out.print(s.getString("phone") + " / ");
			System.out.println(s.getString("address"));
		}
	}
}
