package test01;

public class Member {
	public String name;
	public int age;
	public String code;
	
	public Member(String name, int age, String code) {
		this.name = name;
		this.age = age;
		this.code = code;
	}

	
	@Override
	public int hashCode() {
		return (name+age+code).hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member) {
			Member tmp = (Member)obj;
			return name.equals(tmp.name) && age == tmp.age && code.equals(tmp.code);
		}
		return false;
	}
	
}
