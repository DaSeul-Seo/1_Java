package test01;

public class test04 {
	String name = "�ڹٸ�";
	String code = "123-456";
	int amount = 10000;
	int wtd;
	int dps;
	
	public void withdraw(int wtd) {
		if(amount < wtd) {
			System.out.println("�ܾ��� �����մϴ�.");
		}
		else {
			System.out.println(wtd + "���� ����մϴ�.");
		}
	}
	
	public void deposit(int dps) {
		amount += dps;
		System.out.println(amount);
	}
	
	
	@Override
	public String toString() {
		return "������ : " + name + ", ���¹�ȣ : " + code + ", �ܾ� : " + amount;
	}

	public static void main(String[] args) {
		test04 test = new test04();
		
		test.withdraw(15000);
		System.out.println(test.toString());
		
		test.deposit(30000);
		System.out.println(test.toString());
		
	}
}
