package test01;

public class test03 {
	String name = "ȫ�浿";
	String code = "123-456-789";
	int amount = 500000;
	int wtd;
	int dps;
	
	public void withdraw() {
		if(amount < wtd) {
			System.out.println("�ܾ��� �����մϴ�.");
		}
		else {
			System.out.println(wtd);
		}
	}
	
	public void deposit() {
		amount += dps;
		System.out.println(amount);
	}
	
	
	@Override
	public String toString() {
		return "������ : " + name + ", ���¹�ȣ : " + code + ", �ܾ� : " + amount;
	}

	public static void main(String[] args) {
		test03 test = new test03();
		
		System.out.println(test.toString());
	}
}
